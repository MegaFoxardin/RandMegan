__name__ = "RandMegan"
__version__ = "0.0.3.13"
__version_tuple__ = (0, 0, 3, 13)
import secrety as _secrety
from secrety import randbelow as _rbelow, token_bytes as _rbytes, token_urlsafe as _rurl
_secrety.__Imported_678_999 = False
DefaultEntropy = 64


def Panic(Err):
    raise Err


def boolRandom():
    return True if intRandom(0, 1) == 1 else False


def intRandom(num=1, svm=DefaultEntropy):
    if num >= svm:
        Panic(ValueError(f"({num} >= {svm}) The minimum value should not be higher nor equal to maximum value. \nDid you mean to use 'intRandom({svm}, {num})' instead?"))
    if num < 0 or svm < 0:
        Panic(ValueError(f"({num if num < 0 else svm} < {0x00}) The minimum value and maximum value should not be less than 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?"))
    return _rbelow((svm + 1) - num) + num


def intRandomPlus(num=1, svm=[_ for _ in range(DefaultEntropy)]):
    return intRandom(num, len(svm))


def intRandomBelow(svm=DefaultEntropy):
    if svm <= 0:
        Panic(ValueError(f"({svm} <= {0x00}) The value of 'intRandomBelow()' should not be less than nor equal to 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?"))
    return _rbelow(svm)


def stRandom(text="Hello, RandMegan!"):
    if text == '':
        Panic(ValueError(f"{text} is an empty string. Did you mean to not use an Empty String?"))
    return text[intRandomBelow(len(text))]


def TokenPassword(length=DefaultEntropy, Exclude_SpecialChar=False, Exclude_Digits=False):
    Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*(){}[]|\\/?<>=+_-'\"`~"
    if Exclude_SpecialChar and Exclude_Digits:
        Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    elif Exclude_SpecialChar:
        Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    elif Exclude_Digits:
        Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*(){}[]|\\/?<>=+_-'\"`~"
    c = ""
    for i in range(length):
        c += stRandom(Chars)
    return c


def Shuffle(List=[intRandomBelow(DefaultEntropy) for _ in range(DefaultEntropy)]):
    if not List:
        Panic(ValueError(f"{List} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?"))
    X = len(List) - 1
    while X > 0:
        V = intRandom(0, X)
        List[V], List[X] = List[X], List[V]
        X -= 1
    return List


def RandomBytes(bytes=DefaultEntropy):
    if bytes < 1:
        Panic(ValueError(f"{bytes} in the call of 'RandomBytes({bytes})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _rbytes(bytes)


def RandomHex(bytes=DefaultEntropy):
    if bytes < 1:
        Panic(ValueError(f"{bytes} in the call of 'RandomHex({bytes})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return RandomBytes(bytes).hex()


def chooseRandom(svm=[1,3.14,"hello, world",True]):
    if not svm:
        Panic(ValueError(f"{svm} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?"))
    return svm[intRandom(0, len(svm)-1)]


def choosePlusified(List=[1,3.14,"hello, world",True]):
    return chooseRandom(Shuffle(List))


def RandUrlsafe(svm=DefaultEntropy):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'RandUrlsafe({svm})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _rurl(svm)


def RandUrlsafePlus(svm=DefaultEntropy):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'RandUrlsafePlus({svm})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _rurl(intRandom(0, svm))


def randBitArray(svm=DefaultEntropy):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'randBitArray({svm})' is less than 1 bit. \nDid you mean to use a positive value, instead of a negative value?"))
    return [intRandom(0, 1) for _ in range(svm)]


def randBits(svm=DefaultEntropy):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'randBits({svm})' is less than 1 bit. \nDid you mean to use a positive value, instead of a negative value?"))
    x = f"{intRandom(0, 1)}"
    for _ in range(svm-1):
        x += f"{intRandom(0, 1)}"
    return x


def RandDice4():
    return intRandom(1, 4)


def RandDice6():
    return intRandom(1, 6)


def RandDice8():
    return intRandom(1, 8)


def RandDice10():
    return intRandom(1, 10)


def RandDice12():
    return intRandom(1, 12)


def RandDice16():
    return intRandom(1, 16)


def RandDice20():
    return intRandom(1, 20)


def RandColour(min=0, max=255):
    return intRandom(min, max), intRandom(min, max), intRandom(min, max)


def Negativify(num, suppress=False):
    if num == 0 and not suppress:
        Panic(SyntaxWarning(f"{num} is in a value of 0, and the call of 'Negativify({num})' is not necessary. \nDid you mean to use a different number value, rather than 0?"))
    return ~(num-1)


def Power(num, svm):
    return num ** svm
