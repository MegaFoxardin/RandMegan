__name__ = "RandMegan"
__version__ = "0.0.3.7"
__version_tuple__ = (0, 0, 3, 6)
from secrety import randbelow as _rbelow, token_bytes as _rbytes
def boolrandom():
    return True if (intrandom(0, 1) == 1) else False
def intrandom(num=1,svm=10):
    if num >= svm:
        raise ValueError(f"({num} >= {svm}) The minimum value should not be higher nor equal to maximum value. \nDid you mean to use 'intrandom({svm}, {num})' instead?")
    elif num < 0:
        raise ValueError(f"({num} < {0x00}) The minimum value should not be less than 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?")
    return _rbelow(svm - num) + num
def intrandomplus(num=1,svm=[0, 1, 2]):
    return intrandom(num, len(svm)-1)
def intrandombelow(svm=10):
    if svm <= 0:
        raise ValueError(f"({svm} <= {0x00}) The value of intrandombelow() should not be less than nor equal to 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?")
    return _rbelow(svm)
def strandom(text='hello, world'):
    if text == '':
        raise ValueError(f"{text} is an empty string. Did you mean to not use an Empty String?")
    return text[intrandom(0, len(text)-1)]
def Shuffle(List):
    if not List:
        raise ValueError(f"{List} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?")
    X = len(List) - 1
    while X > 0:
        V = intrandom(0, X)
        List[V], List[X] = List[X], List[V]
        X -= 1
    return List
def RandomBytes(bytes):
    return _rbytes(bytes)
def chooserandom(svm=[1,3.14,'hello, world',True]):
    if not svm:
        raise ValueError(f"{svm} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?")
    return svm[intrandom(0, len(svm)-1)]
def chooseplusified(List):
    return chooserandom(Shuffle(List))
