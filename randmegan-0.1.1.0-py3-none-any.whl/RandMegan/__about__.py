__name__ = "RandMegan"
__version__ = "0.1.1.0"
__author__ = "Fox Consolas"
__author_email__ = "foxrobinleela@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright © 2025 Fox Consolas"
__version_tuple__ = (0, 1, 1, 0)
