__name__ = "RandMegan"
__version__ = "0.0.3.6"
__version_tuple__ = (0, 0, 3, 6)
from randy import randint as _randint, randbytes as _rbytes
def boolrandom():
    return True if (intrandom(0, 1) == 1) else False
def intrandom(num=1,svm=10):
    return _randint(num, svm)
def intrandomplus(num=1,svm=[0, 1, 2]):
    return intrandom(num, len(svm)-1)
def strandom(text='hello, world'):
    return text[intrandom(0, len(text)-1)]
def Shuffle(List):
    X = len(List) - 1
    while X > 0:
        V = intrandom(0, X)
        List[V], List[X] = List[X], List[V]
        X -= 1
    return List
def RandomBytes(bytes):
    return _rbytes(bytes)
def chooserandom(svm=[1,3.14,'hello, world',True]):
    return svm[intrandom(0, len(svm)-1)]
def chooseplusified(List):
    return chooserandom(Shuffle(List))