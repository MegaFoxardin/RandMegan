__name__ = "RandMegan"
__version__ = "0.0.4.0"
__author__ = "FoxyCS"
__author_email__ = "foxrobinleela@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright © 2024 FoxyCS"
__version_tuple__ = (0, 0, 4, 0)
