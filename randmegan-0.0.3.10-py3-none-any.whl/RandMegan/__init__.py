__name__ = "RandMegan"
__version__ = "0.0.3.10"
__version_tuple__ = (0, 0, 3, 10)
from secrety import randbelow as _rbelow, token_bytes as _randbytes, token_hex as _randhex, token_urlsafe as _randurlsafe

def Panic(Err):
    raise Err

def boolRandom():
    return True if (intRandom(0, 2) == 1) else False


def intRandom(num=1,svm=10):
    if num >= svm:
        Panic(ValueError(f"({num} >= {svm}) The minimum value should not be higher nor equal to maximum value. \nDid you mean to use 'intRandom({svm}, {num})' instead?"))
    if num < 0 or svm < 0:
        Panic(ValueError(f"({num if num < 0 else svm} < {0x00}) The minimum value should not be less than 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?"))
    return _rbelow((svm + 1) - num) + num


def intRandomPlus(num=1,svm=[0, 1, 2]):
    return intRandom(num, len(svm))


def intRandomBelow(svm=10):
    if svm <= 0:
        Panic(ValueError(f"({svm} <= {0x00}) The value of 'intRandomBelow()' should not be less than nor equal to 0 (Zero) \nDid you mean to use a positive value, instead of a negative value?"))
    return _rbelow(svm)


def stRandom(text='hello, world'):
    if text == '':
        Panic(ValueError(f"{text} is an empty string. Did you mean to not use an Empty String?"))
    return text[intRandom(0, len(text)-1)]


def Shuffle(List):
    if not List:
        Panic(ValueError(f"{List} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?"))
    X = len(List) - 1
    while X > 0:
        V = intRandom(0, X)
        List[V], List[X] = List[X], List[V]
        X -= 1
    return List


def RandomBytes(bytes):
    if bytes < 1:
        Panic(ValueError(f"{bytes} in the call of 'RandomBytes({bytes})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _randbytes(bytes)


def RandomHex(bytes):
    if bytes < 1:
        Panic(ValueError(f"{bytes} in the call of 'RandomHex({bytes})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _randhex(bytes)


def chooseRandom(svm=[1,3.14,'hello, world',True]):
    if not svm:
        Panic(ValueError(f"{svm} is an Empty Array (Also known as an 'Empty List') \nDid you mean to use an Array that is not empty?"))
    return svm[intRandom(0, len(svm)-1)]


def choosePlusified(List):
    return chooseRandom(Shuffle(List))


def RandUrlsafe(svm=10):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'RandUrlsafe({svm})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _randurlsafe(svm)

def RandUrlsafePlus(svm=10):
    if svm < 1:
        Panic(ValueError(f"{svm} in the call of 'RandUrlsafePlus({svm})' is less than 1 byte. \nDid you mean to use a positive value, instead of a negative value?"))
    return _randurlsafe(intRandomBelow(svm) + 1)


def Negativify(num, suppress=False):
    if num == 0 and not suppress:
        Panic(SyntaxWarning(f"{num} is in a value of 0, and the call of 'Negativify({num})' is not necessary. \nDid you mean to use a different number value, rather than 0?"))
    return ~(num-1)


def Power(num, svm):
    return num ** svm
