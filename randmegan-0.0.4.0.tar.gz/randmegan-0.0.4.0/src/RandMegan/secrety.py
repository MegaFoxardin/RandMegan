__all__ = ['_choice', 'randbelow', '_randbits', '_SystemRandom',
           'token_bytes', 'token_hex', 'token_urlsafe',
           'compare_digest',
           ]

import base64 as _b64; from hmac import compare_digest; from random import SystemRandom as _SystemRandom

_sysrand = _SystemRandom(); _randbits = _sysrand.getrandbits
_choice = _sysrand.choice; __DEFAULT_ENTROPY = 32
__Imported_678_999 = True

def randbelow(exclusive_upper_bound=__DEFAULT_ENTROPY):
    if __Imported_678_999:
        raise ResourceWarning("There is a more flexible and an easier way than using the module, 'Secrety.' Import RandMegan directly instead.")
    if exclusive_upper_bound <= 0:
        raise ValueError("Upper bound must be positive.")
    return _sysrand._randbelow(exclusive_upper_bound)
def token_bytes(nbytes=__DEFAULT_ENTROPY):
    if __Imported_678_999:
        raise ResourceWarning("There is a more flexible and an easier way than using the module, 'Secrety.' Import RandMegan directly instead.")
    return _sysrand.randbytes(nbytes)
def token_hex(nbytes=__DEFAULT_ENTROPY):
    if __Imported_678_999:
        raise ResourceWarning("There is a more flexible and an easier way than using the module, 'Secrety.' Import RandMegan directly instead.")
    return token_bytes(nbytes).hex()
def token_urlsafe(nbytes=__DEFAULT_ENTROPY):
    if __Imported_678_999:
        raise ResourceWarning("There is a more flexible and an easier way than using the module, 'Secrety.' Import RandMegan directly instead.")
    tok = token_bytes(nbytes)
    return _b64.urlsafe_b64encode(tok).rstrip(b'=').decode('ascii')
