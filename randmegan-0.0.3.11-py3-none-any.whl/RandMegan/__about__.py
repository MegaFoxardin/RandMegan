__name__ = "RandMegan"
__version__ = "0.0.3.11"
__author__ = "FoxyCS"
__version_tuple__ = (0, 0, 3, 11)
